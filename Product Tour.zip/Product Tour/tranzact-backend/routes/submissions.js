const express = require('express');
const router  = express.Router();
const Submission = require('../models/Submission');


function computeResults(revenueCr, marginPct) {
  const newRevenue = revenueCr * 1.134;
  const currentProfit = revenueCr * (marginPct / 100);
  const currentCost   = revenueCr - currentProfit;
  const newCost       = currentCost * (1 - 0.0513);
  const newProfit     = newRevenue - newCost;

  const oldProfit     = currentProfit;
  const profitGrowth  = oldProfit > 0
    ? ((newProfit - oldProfit) / oldProfit) * 100
    : 0;

  return {
    newRevenueCr:     parseFloat(newRevenue.toFixed(2)),
    newCostCr:        parseFloat(newCost.toFixed(2)),
    newProfitCr:      parseFloat(newProfit.toFixed(2)),
    revenueGrowthPct: 13.4,
    costReductionPct: 5.13,
    profitGrowthPct:  parseFloat(profitGrowth.toFixed(2))
  };
}

router.post('/', async (req, res) => {
  try {
    const {
      industry,
      answers,
      annualRevenueCr,
      operatingMarginPct
    } = req.body;


    if (!industry || !answers || annualRevenueCr == null || operatingMarginPct == null) {
      return res.status(400).json({
        error: 'Missing required fields: industry, answers, annualRevenueCr, operatingMarginPct'
      });
    }

    const { salesOrdersOnTime, paymentsOnTime, purchaseOrdersOnTime, deadStock, productionOnTime } = answers;
    if (!salesOrdersOnTime || !paymentsOnTime || !purchaseOrdersOnTime || !deadStock || !productionOnTime) {
      return res.status(400).json({ error: 'All 5 survey answers are required' });
    }

    const results = computeResults(Number(annualRevenueCr), Number(operatingMarginPct));

    const submission = await Submission.create({
      industry,
      answers,
      annualRevenueCr: Number(annualRevenueCr),
      operatingMarginPct: Number(operatingMarginPct),
      results,
      ipAddress: req.ip,
      userAgent: req.headers['user-agent']
    });

    res.status(201).json({ success: true, data: submission });
  } catch (err) {
    if (err.name === 'ValidationError') {
      return res.status(400).json({ error: err.message });
    }
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});


router.get('/', async (req, res) => {
  try {
    const filter = {};
    if (req.query.industry) filter.industry = req.query.industry;

    const submissions = await Submission.find(filter).sort({ createdAt: -1 });
    res.json({ success: true, count: submissions.length, data: submissions });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const submission = await Submission.findById(req.params.id);
    if (!submission) return res.status(404).json({ error: 'Submission not found' });
    res.json({ success: true, data: submission });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});


router.delete('/:id', async (req, res) => {
  try {
    const submission = await Submission.findByIdAndDelete(req.params.id);
    if (!submission) return res.status(404).json({ error: 'Submission not found' });
    res.json({ success: true, message: 'Deleted' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});


router.get('/stats/summary', async (req, res) => {
  try {
    const [byIndustry, totals] = await Promise.all([
      Submission.aggregate([
        { $group: { _id: '$industry', count: { $sum: 1 }, avgProfitGrowth: { $avg: '$results.profitGrowthPct' } } },
        { $sort: { count: -1 } }
      ]),
      Submission.aggregate([
        {
          $group: {
            _id: null,
            total: { $sum: 1 },
            avgProfitGrowth: { $avg: '$results.profitGrowthPct' },
            avgRevenue: { $avg: '$annualRevenueCr' }
          }
        }
      ])
    ]);

    res.json({
      success: true,
      data: {
        totals: totals[0] || { total: 0, avgProfitGrowth: 0, avgRevenue: 0 },
        byIndustry
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
