require('dotenv').config();

const express  = require('express');
const mongoose = require('mongoose');
const cors     = require('cors');
const path     = require('path');

const submissionsRouter = require('./routes/submissions');

const app  = express();
const PORT = process.env.PORT || 5000;


app.use(cors());
app.use(express.json());


app.use(express.static(path.join(__dirname, 'public')));


app.use('/api/submissions', submissionsRouter);


app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});


app.get('/{*splat}', (_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});


const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/tranzact';

mongoose
  .connect(MONGO_URI)
  .then(() => {
    console.log('✅  MongoDB connected');
    app.listen(PORT, () => {
      console.log(`🚀  Server running at http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.error('❌  MongoDB connection failed:', err.message);
    process.exit(1);
  });

module.exports = app;