# TranZact ROI Calculator — Backend

Node.js + Express + MongoDB backend for the TranZact ROI Calculator project.

## Project Structure

```
tranzact-backend/
├── server.js               ← Express entry point
├── .env.example            ← Copy to .env and fill in
├── models/
│   └── Submission.js       ← Mongoose schema
├── routes/
│   └── submissions.js      ← REST API routes
└── public/                 ← Frontend (copy your HTML files here)
    ├── index.html
    ├── tranzact.html
    ├── Final.html
    └── assets/
        └── letstranzact_logo.jfif
```

## Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Configure environment
```bash
cp .env.example .env
```
Edit `.env`:
```
PORT=5000
MONGO_URI=mongodb://localhost:27017/tranzact
# OR for MongoDB Atlas:
# MONGO_URI=mongodb+srv://<user>:<pass>@cluster.mongodb.net/tranzact
```

### 3. Start the server
```bash
npm start
```
Open http://localhost:5000

---

## API Reference

### Submit a completed quiz
```
POST /api/submissions
Content-Type: application/json

{
  "industry": "food",
  "answers": {
    "salesOrdersOnTime":    "50-75%",
    "paymentsOnTime":       "75-100%",
    "purchaseOrdersOnTime": "25-50%",
    "deadStock":            "0-25%",
    "productionOnTime":     "75-100%"
  },
  "annualRevenueCr": 50,
  "operatingMarginPct": 20
}
```
**Response 201:**
```json
{
  "success": true,
  "data": { "_id": "...", "results": { "newRevenueCr": 56.7, ... }, ... }
}
```

### List all submissions
```
GET /api/submissions
GET /api/submissions?industry=food
```

### Get one submission
```
GET /api/submissions/:id
```

### Delete a submission
```
DELETE /api/submissions/:id
```

### Analytics summary
```
GET /api/submissions/stats/summary
```
Returns total count, average profit growth, and breakdown by industry.

### Health check
```
GET /api/health
```

---

## How the frontend connects

| Page | What it does |
|------|-------------|
| `index.html` | Saves selected industry to `sessionStorage` |
| `tranzact.html` | Saves each answer to `sessionStorage` as user progresses |
| `Final.html` | On load, reads industry + answers from `sessionStorage`, POSTs to `/api/submissions` |

No page reloads or extra forms needed — it happens automatically in the background.
