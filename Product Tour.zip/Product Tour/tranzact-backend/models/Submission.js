const mongoose = require('mongoose');

const submissionSchema = new mongoose.Schema(
  {
    // From index.html – industry dropdown
    industry: {
      type: String,
      required: true,
      enum: [
        'fashion', 'food', 'gems', 'industrial', 'mechanical',
        'automotive', 'electrical', 'chemicals', 'plastic',
        'packaging', 'metals', 'Instruments', 'petroleum',
        'drugs', 'building', 'apparel', 'textiles'
      ]
    },

    // From tranzact.html – 5 survey questions
    // Each answer is one of: '0-25%', '25-50%', '50-75%', '75-100%', "I don't know"
    answers: {
      salesOrdersOnTime: { type: String, required: true },
      paymentsOnTime:    { type: String, required: true },
      purchaseOrdersOnTime: { type: String, required: true },
      deadStock:         { type: String, required: true },
      productionOnTime:  { type: String, required: true }
    },

    // From Final.html – revenue/margin inputs
    annualRevenueCr:  { type: Number, required: true },   // e.g. 50
    operatingMarginPct: { type: Number, required: true }, // e.g. 20

    // Computed results (stored for reporting)
    results: {
      newRevenueCr: Number,
      newCostCr:    Number,
      newProfitCr:  Number,
      revenueGrowthPct: Number,   // +13.4
      costReductionPct: Number,   // -5.13
      profitGrowthPct:  Number    // computed dynamically
    },

    // Optional: capture where the lead came from
    ipAddress: String,
    userAgent: String
  },
  { timestamps: true }
);

module.exports = mongoose.model('Submission', submissionSchema);
